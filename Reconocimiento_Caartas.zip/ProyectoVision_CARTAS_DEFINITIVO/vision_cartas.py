from pathlib import Path
import cv2 as cv
import numpy as np

CARD_W = 600
CARD_H = 900
MED_X0, MED_X1 = 0.25, 0.75
MED_Y0, MED_Y1 = 0.63, 0.96
CARD_NAMES = ["hongo", "vendaval", "marea", "rayo", "volcan"]


def order_points(pts):
    pts = np.asarray(pts, dtype=np.float32).reshape(4, 2)
    s = pts.sum(axis=1)
    d = np.diff(pts, axis=1).ravel()
    ordered = np.zeros((4, 2), dtype=np.float32)
    ordered[0] = pts[np.argmin(s)]
    ordered[2] = pts[np.argmax(s)]
    ordered[1] = pts[np.argmin(d)]
    ordered[3] = pts[np.argmax(d)]
    return ordered


def detect_card_quad(frame):
    """Devuelve las 4 esquinas de la carta más probable o None."""
    h, w = frame.shape[:2]
    frame_area = h * w

    gray = cv.cvtColor(frame, cv.COLOR_BGR2GRAY)
    gray = cv.GaussianBlur(gray, (5, 5), 0)

    edges = cv.Canny(gray, 50, 150)
    kernel = cv.getStructuringElement(cv.MORPH_RECT, (5, 5))
    edges = cv.morphologyEx(edges, cv.MORPH_CLOSE, kernel, iterations=2)

    contours, _ = cv.findContours(edges, cv.RETR_EXTERNAL, cv.CHAIN_APPROX_SIMPLE)
    contours = sorted(contours, key=cv.contourArea, reverse=True)

    for cnt in contours[:20]:
        area = cv.contourArea(cnt)
        if area < 0.06 * frame_area or area > 0.95 * frame_area:
            continue

        peri = cv.arcLength(cnt, True)
        approx = None
        for eps in (0.015, 0.02, 0.025, 0.03, 0.04):
            candidate = cv.approxPolyDP(cnt, eps * peri, True)
            if len(candidate) == 4 and cv.isContourConvex(candidate):
                approx = candidate
                break
        if approx is None:
            continue

        pts = order_points(approx.reshape(4, 2))
        top = np.linalg.norm(pts[1] - pts[0])
        bottom = np.linalg.norm(pts[2] - pts[3])
        left = np.linalg.norm(pts[3] - pts[0])
        right = np.linalg.norm(pts[2] - pts[1])
        ww = (top + bottom) / 2.0
        hh = (left + right) / 2.0
        if ww <= 1 or hh <= 1:
            continue

        ratio = min(ww, hh) / max(ww, hh)
        if 0.50 <= ratio <= 0.80:
            return pts

    return None


def warp_card(frame, quad, width=CARD_W, height=CARD_H):
    src = order_points(quad)
    top = np.linalg.norm(src[1] - src[0])
    left = np.linalg.norm(src[3] - src[0])
    if top > left:
        src = np.array([src[1], src[2], src[3], src[0]], dtype=np.float32)

    dst = np.array(
        [[0, 0], [width - 1, 0], [width - 1, height - 1], [0, height - 1]],
        dtype=np.float32,
    )
    M = cv.getPerspectiveTransform(src, dst)
    return cv.warpPerspective(frame, M, (width, height))


def crop_medallion(card):
    h, w = card.shape[:2]
    x0, x1 = int(MED_X0 * w), int(MED_X1 * w)
    y0, y1 = int(MED_Y0 * h), int(MED_Y1 * h)
    return card[y0:y1, x0:x1].copy()


def _circle_mask(shape, radius_fraction=0.31):
    """Máscara del interior del medallón, evitando marco y adornos."""
    h, w = shape[:2]
    yy, xx = np.ogrid[:h, :w]
    cx, cy = w / 2.0, h / 2.0
    r = min(h, w) * radius_fraction
    return ((xx - cx) ** 2 + (yy - cy) ** 2) <= r * r


def color_descriptor(medallion):
    """Descriptor robusto del fondo del medallón en HSV y LAB."""
    med = cv.resize(medallion, (400, 400), interpolation=cv.INTER_AREA)
    hsv = cv.cvtColor(med, cv.COLOR_BGR2HSV)
    lab = cv.cvtColor(med, cv.COLOR_BGR2LAB)
    H, S, V = cv.split(hsv)

    circle = _circle_mask(med.shape, 0.31)

    # Quitamos el símbolo del cálculo del color de fondo.
    white_symbol = (V > 165) & (S < 90)
    yellow_symbol = (H >= 18) & (H <= 40) & (S > 110) & (V > 140)
    valid = circle & ~(white_symbol | yellow_symbol)

    if np.count_nonzero(valid) < 100:
        valid = circle

    lab_pixels = lab[valid]
    hsv_pixels = hsv[valid]

    lab_med = np.median(lab_pixels, axis=0).astype(np.float32)
    hsv_med = np.median(hsv_pixels, axis=0).astype(np.float32)

    return {"lab": lab_med, "hsv": hsv_med}


def extract_symbol_mask(medallion):
    """Extrae solo el símbolo central; ignora borde y reflejos periféricos."""
    med = cv.resize(medallion, (400, 400), interpolation=cv.INTER_AREA)
    hsv = cv.cvtColor(med, cv.COLOR_BGR2HSV)
    H, S, V = cv.split(hsv)
    circle = _circle_mask(med.shape, 0.31)

    # Blanco real: brillo alto y saturación baja.
    white = (V > 165) & (S < 90)
    # Amarillo del Rayo.
    yellow = (H >= 18) & (H <= 40) & (S > 110) & (V > 140)

    mask = ((white | yellow) & circle).astype(np.uint8) * 255

    # Limpieza suave. Un kernel menor conserva mejor seta/gota/rayas.
    k3 = np.ones((3, 3), np.uint8)
    k5 = np.ones((5, 5), np.uint8)
    mask = cv.morphologyEx(mask, cv.MORPH_OPEN, k3, iterations=1)
    mask = cv.morphologyEx(mask, cv.MORPH_CLOSE, k5, iterations=1)

    # Quitar componentes pequeños y reflejos. Priorizamos componentes centrales.
    n, labels, stats, centroids = cv.connectedComponentsWithStats(mask, 8)
    clean = np.zeros_like(mask)
    h, w = mask.shape
    cx, cy = w / 2.0, h / 2.0

    components = []
    for i in range(1, n):
        area = stats[i, cv.CC_STAT_AREA]
        if area < 180:
            continue
        x, y = centroids[i]
        dist = np.hypot(x - cx, y - cy) / (min(h, w) / 2.0)
        # Símbolo grande + cercanía al centro.
        quality = area * max(0.20, 1.20 - dist)
        components.append((quality, i, area))

    # Conservamos hasta 4 componentes relevantes: Vendaval tiene varias trazas.
    components.sort(reverse=True)
    for _, i, area in components[:4]:
        if area >= 180:
            clean[labels == i] = 255

    ys, xs = np.where(clean > 0)
    if len(xs) == 0:
        return np.zeros((240, 240), np.uint8)

    x0, x1 = xs.min(), xs.max()
    y0, y1 = ys.min(), ys.max()
    symbol = clean[y0:y1 + 1, x0:x1 + 1]

    sh, sw = symbol.shape
    size = max(sh, sw)
    square = np.zeros((size, size), np.uint8)
    oy = (size - sh) // 2
    ox = (size - sw) // 2
    square[oy:oy + sh, ox:ox + sw] = symbol
    return cv.resize(square, (240, 240), interpolation=cv.INTER_NEAREST)


def dice_similarity(a, b):
    a = a > 0
    b = b > 0
    denom = a.sum() + b.sum()
    if denom == 0:
        return 0.0
    return float(2.0 * np.logical_and(a, b).sum() / denom)


def _hue_distance(a, b):
    return min(abs(float(a) - float(b)), 180.0 - abs(float(a) - float(b)))


def _element_color_prior(hsv):
    """Pista fuerte por color para impedir confusiones absurdas (p.ej. Hongo/Rayo)."""
    h, s, v = map(float, hsv)
    prior = {name: 0.10 for name in CARD_NAMES}

    # Fondo negro/gris muy oscuro -> Rayo
    if s < 80 and v < 80:
        prior["rayo"] = 1.00
        return prior

    # Con fondos coloreados, usamos el tono.
    if s > 100:
        if h <= 15 or h >= 170:
            prior["volcan"] = 1.00
        elif 35 <= h <= 80:
            prior["hongo"] = 1.00
        elif 80 < h <= 99:
            prior["vendaval"] = 1.00
        elif 99 < h <= 125:
            prior["marea"] = 1.00

    return prior


class CardClassifier:
    def __init__(self, reference_dir):
        self.reference_dir = Path(reference_dir)
        self.references = {}
        self._load_references()

    def _load_references(self):
        for name in CARD_NAMES:
            path = self.reference_dir / f"{name}.png"
            img = cv.imread(str(path))
            if img is None:
                raise FileNotFoundError(f"No se pudo leer la referencia: {path}")
            med = crop_medallion(img)
            self.references[name] = {
                "color": color_descriptor(med),
                "mask": extract_symbol_mask(med),
            }

    def classify(self, card):
        med = crop_medallion(card)
        color = color_descriptor(med)
        mask = extract_symbol_mask(med)

        cand_h, cand_s, cand_v = color["hsv"]
        prior = _element_color_prior(color["hsv"])
        scored = []

        for name, ref in self.references.items():
            ref_h, ref_s, ref_v = ref["color"]["hsv"]
            lab_dist = float(np.linalg.norm(color["lab"] - ref["color"]["lab"]))
            shape_sim = dice_similarity(mask, ref["mask"])

            # Similitud de color con referencia.
            if ref_s < 80:
                color_score = float(
                    np.exp(-abs(float(cand_s) - float(ref_s)) / 40.0)
                    * np.exp(-abs(float(cand_v) - float(ref_v)) / 90.0)
                )
            elif cand_s < 80:
                color_score = 0.02
            else:
                hd = _hue_distance(cand_h, ref_h)
                color_score = float(
                    np.exp(-hd / 10.0)
                    * np.exp(-abs(float(cand_s) - float(ref_s)) / 120.0)
                )

            lab_score = float(np.exp(-lab_dist / 55.0))
            color_score = 0.80 * color_score + 0.20 * lab_score

            # Color manda más que antes; forma confirma.
            base_score = 0.62 * color_score + 0.38 * shape_sim

            # Prior fuerte por familia cromática: evita Hongo->Rayo por reflejos.
            score = 0.75 * base_score + 0.25 * prior[name]

            scored.append((score, name, lab_dist, shape_sim, color_score, prior[name]))

        scored.sort(reverse=True)
        best = scored[0]
        second = scored[1]

        margin = max(0.0, best[0] - second[0])
        confidence = max(0.0, min(1.0, 0.70 * best[0] + 0.30 * margin * 2.5))

        return {
            "name": best[1],
            "score": best[0],
            "confidence": confidence,
            "color_distance": best[2],
            "shape_similarity": best[3],
            "all_scores": scored,
            "medallion": med,
            "symbol_mask": mask,
        }
