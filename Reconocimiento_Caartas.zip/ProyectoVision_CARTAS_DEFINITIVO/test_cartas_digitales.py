from pathlib import Path
import cv2 as cv
from vision_cartas import CardClassifier

ROOT = Path(__file__).resolve().parent
CARDS = ROOT / "cartas"

classifier = CardClassifier(CARDS)

correct = 0
for path in sorted(CARDS.glob("*.png")):
    img = cv.imread(str(path))
    result = classifier.classify(img)
    expected = path.stem
    predicted = result["name"]
    ok = expected == predicted
    correct += int(ok)
    print(
        f"{expected:9s} -> {predicted:9s} "
        f"score={result['score']:.3f} "
        f"color={result['color_distance']:.1f} "
        f"forma={result['shape_similarity']:.3f} "
        f"{'OK' if ok else 'ERROR'}"
    )

print(f"\nResultado: {correct}/5 correctas")
