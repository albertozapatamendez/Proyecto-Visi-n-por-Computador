PROYECTO VISION - RECONOCIMIENTO DE CARTAS (VERSION DEFINITIVA DEL BLOQUE CARTAS)

Archivos principales:
- reconocimiento_cartas.py -> ejecutar este archivo para usar la webcam.
- vision_cartas.py -> funciones de deteccion, perspectiva, medallon y clasificacion.
- test_cartas_digitales.py -> prueba las 5 referencias digitales.
- cartas/ -> referencias: hongo, marea, rayo, vendaval y volcan.

Ejecucion:
1) Situarse en esta carpeta.
2) Instalar dependencias si hace falta:
   pip3 install -r requirements.txt
3) Comprobar referencias:
   python3 test_cartas_digitales.py
   Debe terminar con: Resultado: 5/5 correctas
4) Ejecutar webcam:
   python3 reconocimiento_cartas.py

Funcionamiento:
- Detecta el contorno de la carta.
- Corrige la perspectiva.
- Normaliza la carta.
- Recorta el medallon inferior.
- Clasifica combinando color del medallon + forma del simbolo.
- La misma carta debe mantenerse reconocida durante 1.0 s antes de confirmarse.
- Q o ESC cierra el programa.

Notas:
- Si la webcam no abre con indice 0, cambiar CAMERA_INDEX = 1 en reconocimiento_cartas.py.
- Papel mate y buena iluminacion reduciran reflejos frente a mostrar la carta en una pantalla.
- Este ZIP corresponde SOLO al bloque de reconocimiento de cartas. Gestos, juego e integracion se desarrollan aparte.
