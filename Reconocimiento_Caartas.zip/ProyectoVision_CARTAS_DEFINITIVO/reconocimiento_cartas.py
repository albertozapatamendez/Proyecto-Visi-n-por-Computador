from pathlib import Path
import time
import cv2 as cv
from vision_cartas import CardClassifier, detect_card_quad, warp_card

ROOT = Path(__file__).resolve().parent
REFERENCES = ROOT / "cartas"
CAMERA_INDEX = 0

# La misma carta debe mantenerse estable este tiempo antes de confirmarla.
CONFIRM_SECONDS = 1.00
# Umbral mínimo de score para aceptar una carta.
MIN_SCORE = 0.38


def main():
    classifier = CardClassifier(REFERENCES)

    cap = cv.VideoCapture(CAMERA_INDEX)
    if not cap.isOpened():
        raise RuntimeError("No se pudo abrir la webcam. Prueba CAMERA_INDEX = 1.")

    cap.set(cv.CAP_PROP_FRAME_WIDTH, 1280)
    cap.set(cv.CAP_PROP_FRAME_HEIGHT, 720)

    stable_name = None
    stable_since = None
    accepted_name = None
    last_seen = 0.0

    print("Reconocimiento de cartas iniciado.")
    print("Muestra una carta A5 a la cámara. Pulsa Q para salir.")
    print(f"Confirmación: {CONFIRM_SECONDS:.2f} s manteniendo la misma carta.")

    while True:
        ok, frame = cap.read()
        if not ok:
            break

        display = frame.copy()
        quad = detect_card_quad(frame)

        if quad is not None:
            warped = warp_card(frame, quad)
            result = classifier.classify(warped)
            name = result["name"].upper()
            score = result["score"]

            pts = quad.astype(int).reshape((-1, 1, 2))
            cv.polylines(display, [pts], True, (0, 255, 0), 3)

            now = time.time()
            if name == stable_name:
                if stable_since is None:
                    stable_since = now
            else:
                stable_name = name
                stable_since = now

            stable_time = 0.0 if stable_since is None else now - stable_since

            # Confirmación real por tiempo, no por número de frames.
            if stable_time >= CONFIRM_SECONDS and score >= MIN_SCORE:
                accepted_name = name
                last_seen = now

            cv.putText(display, f"Candidato: {name}", (20, 40),
                       cv.FONT_HERSHEY_SIMPLEX, 0.9, (0, 255, 255), 2)
            cv.putText(display, f"Score: {score:.2f}", (20, 75),
                       cv.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 255), 2)
            cv.putText(display, f"Estable: {stable_time:.2f}/{CONFIRM_SECONDS:.2f} s", (20, 105),
                       cv.FONT_HERSHEY_SIMPLEX, 0.65, (0, 255, 255), 2)

            small_card = cv.resize(warped, (200, 300))
            small_med = cv.resize(result["medallion"], (180, 180))
            small_mask = cv.cvtColor(
                cv.resize(result["symbol_mask"], (180, 180)),
                cv.COLOR_GRAY2BGR,
            )
            cv.imshow("Carta normalizada", small_card)
            cv.imshow("Medallon", small_med)
            cv.imshow("Simbolo detectado", small_mask)
        else:
            stable_name = None
            stable_since = None

        if accepted_name and time.time() - last_seen < 1.0:
            cv.rectangle(display, (10, 125), (430, 185), (0, 0, 0), -1)
            cv.putText(display, f"TIPO: {accepted_name}", (25, 168),
                       cv.FONT_HERSHEY_SIMPLEX, 1.15, (0, 255, 0), 3)

        cv.putText(display, "Q = salir", (20, display.shape[0] - 20),
                   cv.FONT_HERSHEY_SIMPLEX, 0.65, (255, 255, 255), 2)
        cv.imshow("Reconocimiento de cartas", display)

        key = cv.waitKey(1) & 0xFF
        if key in (ord('q'), ord('Q'), 27):
            break

    cap.release()
    cv.destroyAllWindows()


if __name__ == "__main__":
    main()
